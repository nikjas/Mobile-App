package com.example.mobile;

import  androidx.appcompat.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText user,pass;
    private Button loginBtn;
    private TextView login;
    String emailpattern = "[a-zA-Z0-9._-]+\\.+[a+z]+";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUIViews();

        user = findViewById(R.id.txtUserLogin);
        pass = findViewById(R.id.txtPassLogin);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String username = user.getText().toString();
                final String password = pass.getText().toString();


                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");

                            if(success) {
                                final String username = jsonObject.getString( "username" );

                                Intent intent = new Intent( MainActivity.this, LandingPage.class );
                                intent.putExtra( "Username", username );


                                MainActivity.this.startActivity(intent);

                            }

                            else{
                                //Toast.makeText(sign_up.this,"Failed Insert",Toast.LENGTH_SHORT).show();
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("Mismatched username and password")
                                        .setNegativeButton("Retry", null)
                                        .create()
                                        .show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };

                LoginRequest loginRequest = new LoginRequest(username,password,responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(loginRequest);
            }
        });



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Signup.class));
            }
        });
    }

    private void setupUIViews(){
        user = findViewById(R.id.txtUserLogin);
        pass = findViewById(R.id.txtPassLogin);
        loginBtn = findViewById(R.id.btnLogin);
        login = findViewById(R.id.tvLogin);

    }
}
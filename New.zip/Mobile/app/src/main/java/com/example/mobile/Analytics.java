package com.example.mobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.ReferenceQueue;
import java.net.ResponseCache;
import java.util.ArrayList;

public class Analytics extends AppCompatActivity implements Adapter.OnItemClickListner {
    private RecyclerView recyclerView;
    private Adapter adapter;
    private ArrayList<Variables> arrayList;
    private ArrayList arr;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_analytics);

        recyclerView = findViewById(R.id.recycler_pin);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        arrayList = new ArrayList<>();
        arr =new ArrayList<>();

        requestQueue = Volley.newRequestQueue(this);
        PARSEDATA();
    }
    public void PARSEDATA() {
        String URL = "https://technofarmers.000webhostapp.com/sample.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try{
                    JSONArray jsonArray = response.getJSONArray("server_response");
                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject hit = jsonArray.getJSONObject(i);

                        String waterlevel = hit.getString("SEND_WATERLEVEL");
                        String status = hit.getString("SEND_STATUS");
                        String date = hit.getString("SEND_DATE");

                        arrayList.add(new Variables(waterlevel,null, date));
                        arrayList.add(new Variables(null,status, null));
                        arrayList.add(new Variables(null,null, date));

                        arr.add(waterlevel);
                        arr.add(status);
                        arr.add(date);


                    }

                    adapter = new Adapter(Analytics.this, arrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.setOnItemClickListner(Analytics.this);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }

    @Override
    public void onItemClick(int position) {
        Variables clickitem = arrayList.get(position);

        String waterlevel = clickitem.getWaterlevel();
        Toast.makeText(this, waterlevel, Toast.LENGTH_SHORT).show();


    }
}
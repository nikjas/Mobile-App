package com.example.mobile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Signup extends AppCompatActivity {

    private static final String TAG = "Signup";

    private EditText user, emails, pass, confirms;
    private Button registerBtn;
    private TextView register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_signup );
        setupUIViews();

        registerBtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String username = user.getText().toString();
                final String email = emails.getText().toString();
                final String password = pass.getText().toString();
                final String confirm = confirms.getText().toString();

                if(TextUtils.isEmpty(username)){
                    Log.d(TAG, "Username is empty. Please fill it in .");
                    return;

                }


                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject( response );
                            boolean success = jsonResponse.getBoolean( "success" );

                            if (validate()) {

                                    if(passValidate()){
                                        if (success) {
                                            startActivity(new Intent(Signup.this, MainActivity.class));
                                        }
                                        else {
                                            AlertDialog.Builder builder = new AlertDialog.Builder(Signup.this);
                                            builder.setMessage("Username already exists")
                                                    .setNegativeButton("Retry", null)
                                                    .create()
                                                    .show();
                                        }
                                    }
                                   else{
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Signup.this);
                                        builder.setMessage("Password does not match")
                                                .setNegativeButton("Retry", null)
                                                .create()
                                                .show();
                                    }

                                }


                                else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder( Signup.this );
                                    builder.setMessage( "Invalid Email Address" )
                                            .setNegativeButton( "Retry", null )
                                            .create()
                                            .show();
                                }



//                            else {
//                                //Toast.makeText(sign_up.this,"Failed Insert",Toast.LENGTH_SHORT).show();
//                                AlertDialog.Builder builder = new AlertDialog.Builder( Signup.this );
//                                builder.setMessage( "Please enter a valid email" )
//                                        .setNegativeButton( "Retry", null )
//                                        .create()
//                                        .show();
//                            }

                        }
                        catch(
                                JSONException e)

                        {
                            e.printStackTrace();
                        }
                    }


                };

                RegisterRequest registerRequest = new RegisterRequest( username, email, password, confirm, responseListener );
                RequestQueue queue = Volley.newRequestQueue( Signup.this );
                queue.add( registerRequest );
            }
        } );
    }

    private void setupUIViews() {
        user = findViewById( R.id.txtUser );
        emails = findViewById( R.id.txtEmail );
        pass = findViewById( R.id.txtPass );
        confirms = findViewById( R.id.txtConfirm );
        registerBtn = findViewById( R.id.btnSubmit );
        register = findViewById( R.id.tvSubmit );

    }



    public  boolean validate() {
        boolean isValid = false;

        String email = emails.getText().toString().trim();

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public  boolean passValidate() {
        boolean isValid = false;


        String password = pass.getText().toString().trim();
        String confirm = confirms.getText().toString().trim();
        if (password.equals(confirm)) {
            isValid = true;
        }
        return isValid;
    }

}